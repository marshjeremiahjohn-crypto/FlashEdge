# FlashEdge Command

FlashEdge Command is a testnet-first flash-arbitrage control room for Base and Arbitrum. It includes a React dashboard, a FastAPI backend, Solidity strategy contracts, and an optional scanner package.

> **Safety notice:** The dashboard's strategy scanner is simulated for tuning and discovery. Do not deploy contracts or execute trades on mainnet until the contracts, RPC providers, token approvals, and transaction routes have been independently reviewed and tested.

## Architecture

- `frontend/` — Create React App dashboard with MetaMask integration.
- `backend/` — FastAPI API for scan configuration, live discovery, transaction building, preflight checks, and persistence.
- `contracts/` — Solidity flash-arbitrage contracts; deployment is intentionally manual.
- `scanner/` — Optional Node.js scanner package.
- MongoDB — Required by the backend for saved scans, strategies, deployments, and execution history.

## Local setup

Requirements: Node.js 18+, Python 3.11+, MongoDB, and a browser wallet for wallet-specific features.

```bash
cp .env.example .env
cp frontend/.env.example frontend/.env.local
python3 -m venv .venv
. .venv/bin/activate
pip install -r backend/requirements.txt
npm install --prefix frontend --legacy-peer-deps
```

Start the API and dashboard in separate terminals:

```bash
. .venv/bin/activate
uvicorn backend.server:app --host 0.0.0.0 --port 8001 --reload
```

```bash
cd frontend
npm start
```

The API health probe is `http://localhost:8001/health`; the dashboard is `http://localhost:3000`.

## Production build

```bash
cd frontend
npm install --legacy-peer-deps
npm run build
```

The production frontend is emitted to `frontend/build`. The API runs with:

```bash
uvicorn backend.server:app --host 0.0.0.0 --port ${PORT:-8001}
```

Required hosted API variables:

| Variable | Purpose |
| --- | --- |
| `MONGO_URL` | MongoDB Atlas connection string |
| `DB_NAME` | Database name, for example `flash_arb_engine` |
| `CORS_ORIGINS` | Comma-separated deployed frontend origin(s) |
| `BASE_MAINNET_RPC_URL` | Optional RPC URL for discovery/status checks |
| `ARBITRUM_MAINNET_RPC_URL` | Optional RPC URL for discovery/status checks |
| `BASE_SEPOLIA_RPC_URL` | Optional testnet RPC URL |
| `ARBITRUM_SEPOLIA_RPC_URL` | Optional testnet RPC URL |

Never commit a private key, wallet seed phrase, or production RPC secret. The included UI does not make mainnet execution safe by itself.

## Free hosting recommendation

For this full-stack project, **Render is the simplest free starting point**: deploy the FastAPI service as a free web service and the React output as a free static site in the same account. Add a free MongoDB Atlas database separately, then set `REACT_APP_BACKEND_URL` on the frontend to the deployed API URL and `CORS_ORIGINS` on the API to the deployed frontend URL.

The free API service may sleep when idle, so it is appropriate for demos and development—not latency-sensitive arbitrage execution. For a public frontend-only demo, Netlify or Vercel are also good choices, but neither replaces the FastAPI service and MongoDB.

A `render.yaml` blueprint is included for the API and static frontend. After importing the repository in Render, fill in the secret environment variables and deploy the API first. Then set the frontend backend URL and redeploy the static site.

## Verification checklist

1. `GET /health` returns `{"status":"ok"}`.
2. The frontend build completes without using `--force`.
3. The dashboard can load `/api/config` from the deployed API.
4. MongoDB Atlas connectivity works before using saved-history features.
5. CORS contains the exact frontend origin, including `https://` and no trailing path.
6. Contracts are tested on a testnet and independently audited before any mainnet use.

## License

MIT

## Attribution

Created for Jeremiah's FlashEdge Command project.
