# Flash Arbitrage Engine 3 - Quick Reference

Complete project structure and file reference.

## Project Structure

```
flash-arb-engine-3/
├── scanner/                          # Arbitrage scanning bot
│   ├── bot.js                        # Main scanner logic
│   ├── package.json                  # Scanner dependencies
│   ├── .env.example                  # Environment template
│   ├── Dockerfile                    # Docker container setup
│   ├── docker-compose.yml            # Docker Compose config
│   ├── README.md                     # Scanner documentation
│   ├── logs/                         # Scan logs directory
│   └── __tests__/
│       └── bot.test.js               # Scanner unit tests
│
├── contracts/                        # Smart contracts
│   ├── contracts/
│   │   ├── FlashArbitrageRouter.sol  # Main routing contract
│   │   └── interfaces/               # Contract interfaces
│   ├── scripts/
│   │   └── deploy.js                 # Deployment script
│   ├── test/
│   │   └── FlashArbitrageRouter.test.js  # Contract tests
│   ├── hardhat.config.js             # Hardhat configuration
│   └── package.json                  # Contract dependencies
│
├── frontend/                         # React web interface
│   ├── src/
│   │   ├── App.jsx                   # Main app component
│   │   ├── index.jsx                 # Entry point
│   │   └── components/               # React components
│   ├── public/                       # Static assets
│   ├── __tests__/
│   │   └── App.test.jsx              # Frontend tests
│   ├── package.json                  # Frontend dependencies
│   └── .env.example                  # Environment template
│
├── .github/
│   └── workflows/
│       ├── test.yml                  # CI/CD test pipeline
│       └── deploy.yml                # CI/CD deployment pipeline
│
├── README.md                         # Project overview
├── TESTING.md                        # Testing guide
├── DEPLOYMENT.md                     # Deployment guide
├── SECURITY.md                       # Security policy
├── .env.example                      # Root environment template
├── .gitignore                        # Git ignore rules
├── package.json                      # Root package with scripts
├── docker-compose.yml                # Full stack Docker setup
├── quickstart.sh                     # Quick start script
├── run-tests.sh                      # Test runner script
└── LICENSE                           # MIT License
```

## Key Files Summary

### Configuration Files

| File | Purpose |
|------|---------|
| `.env.example` | Environment variable template (root) |
| `scanner/.env.example` | Scanner environment template |
| `frontend/.env.example` | Frontend environment template |
| `hardhat.config.js` | Smart contract network config |
| `.gitignore` | Git ignore rules |

### Documentation

| File | Purpose |
|------|---------|
| `README.md` | Project overview and setup |
| `TESTING.md` | Complete testing guide |
| `DEPLOYMENT.md` | Deployment instructions |
| `SECURITY.md` | Security best practices |
| `QUICK_REFERENCE.md` | This file |

### Smart Contracts

| File | Purpose |
|------|---------|
| `contracts/contracts/FlashArbitrageRouter.sol` | Main arbitrage router |
| `contracts/scripts/deploy.js` | Contract deployment script |
| `contracts/test/*.test.js` | Contract tests |

### Scanner Bot

| File | Purpose |
|------|---------|
| `scanner/bot.js` | Main scanner bot logic |
| `scanner/package.json` | Scanner dependencies |
| `scanner/.env.example` | Scanner config template |
| `scanner/Dockerfile` | Container image definition |
| `scanner/__tests__/bot.test.js` | Scanner tests |

### Frontend

| File | Purpose |
|------|---------|
| `frontend/src/App.jsx` | Main React component |
| `frontend/src/index.jsx` | React entry point |
| `frontend/__tests__/App.test.jsx` | Frontend tests |
| `frontend/package.json` | Frontend dependencies |

### CI/CD

| File | Purpose |
|------|---------|
| `.github/workflows/test.yml` | Automated testing pipeline |
| `.github/workflows/deploy.yml` | Automated deployment |

### Scripts

| File | Purpose |
|------|---------|
| `run-tests.sh` | Run all tests automatically |
| `quickstart.sh` | Setup and quick start |
| `package.json` | Root scripts (test, build, deploy) |

## Common Commands

### Setup & Installation

```bash
# Quick setup
bash quickstart.sh

# Manual setup
npm install
cd contracts && npm install && cd ..
cd scanner && npm install && cd ..
cd frontend && npm install && cd ..
```

### Testing

```bash
# Run all tests
bash run-tests.sh

# Run specific tests
npm run test:contracts
npm run test:frontend
cd scanner && npm test && cd ..
```

### Development

```bash
# Start frontend
cd frontend && npm start

# Start scanner (dry-run mode)
cd scanner && npm run dev

# View logs
tail -f scanner/logs/scanner-*.log
```

### Deployment

```bash
# Testnet deployment
npm run deploy:testnet
npm run verify:testnet

# Mainnet deployment
npm run deploy:mainnet
npm run verify:mainnet
```

### Docker

```bash
# Build containers
docker-compose build

# Start all services
docker-compose up

# Stop services
docker-compose down

# View logs
docker-compose logs -f scanner
```

## Environment Variables

### Required Variables

**Root & Scanner:**
```env
BASE_RPC                 # Base network RPC endpoint
ARBITRUM_RPC             # Arbitrum network RPC endpoint
FLASH_ROUTER_BASE        # Deployed router address on Base
FLASH_ROUTER_ARBITRUM    # Deployed router address on Arbitrum
PRIVATE_KEY              # Private key for transactions
```

**Scanner Only:**
```env
MIN_PROFIT_THRESHOLD     # Minimum profit % (default: 1.0)
MIN_LIQUIDITY            # Minimum pool liquidity (default: 100000)
SCAN_INTERVAL            # Scan frequency in ms (default: 5000)
AUTO_EXECUTE             # Auto-execute trades (default: true)
DRY_RUN                  # Simulation mode (default: false)
```

**Frontend Only:**
```env
REACT_APP_BASE_RPC       # Base RPC endpoint
REACT_APP_ARBITRUM_RPC   # Arbitrum RPC endpoint
REACT_APP_DEBUG_MODE     # Enable debug mode (default: false)
```

## Test Structure

### Unit Tests

- **Contracts:** `contracts/test/FlashArbitrageRouter.test.js`
- **Scanner:** `scanner/__tests__/bot.test.js`
- **Frontend:** `frontend/src/__tests__/App.test.jsx`

### Integration Tests

- Run via: `npm run test:contracts` (with network)
- Scanner + Contracts: Local hardhat network

### E2E Tests

- Frontend + MetaMask: Manual browser testing
- Full Stack: All services running locally via Docker

## Logging

### Scanner Logs

- **Location:** `scanner/logs/scanner-YYYY-MM-DD.log`
- **Content:** All scan results, opportunities, executions
- **Format:** JSON with timestamps
- **Rotation:** Daily file creation

### Application Logs

- **Frontend:** Browser console (F12)
- **Smart Contracts:** Hardhat console output
- **Scanner:** Console + file logs

## API Integrations

### Supported DEXes

- Uniswap V3
- Uniswap V2
- SushiSwap
- Curve Finance

### RPC Providers

- Infura (configurable)
- Alchemy (configurable)
- Public RPC endpoints (default)

## Git Workflows

### Branching Strategy

```
main/master
  ├── develop (development branch)
  │   ├── feature/scanner-improvements
  │   ├── feature/frontend-ui
  │   └── bugfix/contract-security
  └── (tagged releases)
```

### Making Changes

```bash
# Create feature branch
git checkout -b feature/your-feature

# Commit changes
git commit -m "Add feature"

# Push and create PR
git push origin feature/your-feature
```

## Deployment Checklist

- [ ] All tests passing locally
- [ ] Environment variables configured
- [ ] `.env` files created (not committed)
- [ ] Private keys secured
- [ ] RPC endpoints verified
- [ ] Smart contracts deployed to testnet
- [ ] Contracts verified on block explorer
- [ ] Scanner tested in dry-run mode
- [ ] Frontend builds successfully
- [ ] Security audit completed (mainnet only)

## Cloud Deployment Platforms

### Recommended for Scanner

1. **Railway** - Best for continuous bots ($5/month)
2. **Render** - Good alternative (free tier available)
3. **Heroku** - Reliable (started at $5/month)

### Recommended for Frontend

1. **Vercel** - Best for React apps (free tier)
2. **Netlify** - Great alternative (free tier)
3. **GitHub Pages** - Free (static only)

## Troubleshooting

### Port Conflicts

```bash
# Find process on port
lsof -i :3000
lsof -i :8545

# Kill process
kill -9 <PID>
```

### Missing Dependencies

```bash
# Clean and reinstall
rm -rf node_modules
npm install
```

### Cache Issues

```bash
# Clear Node cache
npm cache clean --force

# Clear hardhat cache
cd contracts && npx hardhat clean && cd ..
```

## Security Reminders

⚠️ **CRITICAL:**
- Never commit `.env` files
- Never share private keys
- Use hardware wallets for mainnet
- Always test on testnet first
- Keep dependencies updated
- Review contract code thoroughly

## Support & Resources

### Documentation
- README.md - Project overview
- TESTING.md - Testing guide
- DEPLOYMENT.md - Deployment guide
- SECURITY.md - Security policy

### External Resources
- [Hardhat Docs](https://hardhat.org)
- [Web3.js Docs](https://web3js.readthedocs.io)
- [React Docs](https://react.dev)
- [Base Docs](https://docs.base.org)
- [Arbitrum Docs](https://docs.arbitrum.io)

## Contact & Support

For issues or questions:
- Check relevant documentation file
- Review TROUBLESHOOTING in TESTING.md
- Check logs in `scanner/logs/`
- Review error messages carefully

---

**Last Updated:** September 3, 2026
**Version:** 1.0.0
**Status:** Production Ready
