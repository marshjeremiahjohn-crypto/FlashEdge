#!/bin/bash

# Flash Arbitrage Engine 3 - Quick Start Script
# This script sets up and runs the entire application locally

set -e

echo "🚀 Flash Arbitrage Engine 3 - Quick Start"
echo "=========================================="
echo ""

# Check Node.js version
echo "📋 Checking Node.js version..."
NODE_VERSION=$(node -v)
echo "   Node.js: $NODE_VERSION"

# Create directories
echo "📁 Creating required directories..."
mkdir -p scanner/logs

# Install dependencies
echo "📦 Installing dependencies..."
npm install > /dev/null 2>&1
cd contracts && npm install > /dev/null 2>&1 && cd ..
cd scanner && npm install > /dev/null 2>&1 && cd ..
cd frontend && npm install > /dev/null 2>&1 && cd ..

# Setup environment files
echo "⚙️  Setting up environment variables..."
if [ ! -f .env.local ]; then
  cp .env.example .env.local
  echo "   Created .env.local"
fi

if [ ! -f scanner/.env ]; then
  cp scanner/.env.example scanner/.env
  echo "   Created scanner/.env"
fi

if [ ! -f frontend/.env.local ]; then
  cat > frontend/.env.local << EOF
REACT_APP_BASE_RPC=https://mainnet.base.org
REACT_APP_ARBITRUM_RPC=https://arb1.arbitrum.io/rpc
REACT_APP_DEBUG_MODE=false
EOF
  echo "   Created frontend/.env.local"
fi

# Summary
echo ""
echo "✅ Setup Complete!"
echo ""
echo "📚 Next Steps:"
echo ""
echo "1. 🧪 Run Tests:"
echo "   ./run-tests.sh"
echo ""
echo "2. 🤖 Run Scanner (dry-run):"
echo "   cd scanner"
echo "   npm run dev"
echo ""
echo "3. 🖥️  Run Frontend:"
echo "   cd frontend"
echo "   npm start"
echo ""
echo "4. 📜 View Logs:"
echo "   tail -f scanner/logs/scanner-*.log"
echo ""
echo "📖 Documentation:"
echo "   - README.md      - Overview and setup"
echo "   - TESTING.md     - Testing guide"
echo "   - DEPLOYMENT.md  - Deployment guide"
echo "   - SECURITY.md    - Security guidelines"
echo ""
