# Flash Arbitrage Scanner Bot

Real-time arbitrage opportunity scanner for Base and Arbitrum networks.

## Features

- ✅ Continuous scanning of multiple DEXes
- ✅ Automatic detection of profitable arbitrage routes
- ✅ 1%+ profit threshold filtering
- ✅ $100k+ minimum liquidity requirement
- ✅ Auto-execution of trades via smart contracts
- ✅ Comprehensive logging of all opportunities and executions
- ✅ Cloud-ready (Railway, Render, Heroku compatible)
- ✅ Real-time trade monitoring

## Quick Start

### Prerequisites

- Node.js 18+
- Private key for transaction signing
- RPC endpoints configured
- Smart contract addresses deployed

### Installation

```bash
cd scanner
npm install
```

### Configuration

1. Copy environment template:
```bash
cp .env.example .env
```

2. Update `.env` with your settings:
```env
BASE_RPC=https://mainnet.base.org
ARBITRUM_RPC=https://arb1.arbitrum.io/rpc
FLASH_ROUTER_BASE=0x...
FLASH_ROUTER_ARBITRUM=0x...
PRIVATE_KEY=your_private_key_here
MIN_PROFIT_THRESHOLD=1.0
MIN_LIQUIDITY=100000
```

### Running Locally

```bash
# Development mode with auto-reload
npm run dev

# Production mode
npm start
```

### Viewing Logs

Logs are automatically saved to `logs/` directory with daily files:

```bash
# View logs in real-time
npm run logs

# Or manually
tail -f logs/scanner-2026-09-03.log
```

## Log File Contents

Each log entry includes:

```
[2026-09-03T10:30:45.123Z] Opportunity found
{
  "id": "timestamp-random",
  "timestamp": "2026-09-03T10:30:45.123Z",
  "network": "Base",
  "token0": "WETH",
  "token1": "USDC",
  "dex1": "Uniswap V3",
  "dex2": "SushiSwap",
  "price1": 2345.67,
  "price2": 2368.90,
  "profitPercent": 1.01,
  "liquidity": 250000,
  "status": "executed",
  "transactionHash": "0x..."
}
```

## Configuration Options

| Variable | Default | Description |
|----------|---------|-------------|
| `BASE_RPC` | https://mainnet.base.org | Base network RPC endpoint |
| `ARBITRUM_RPC` | https://arb1.arbitrum.io/rpc | Arbitrum network RPC endpoint |
| `MIN_PROFIT_THRESHOLD` | 1.0 | Minimum profit percentage to execute trade |
| `MIN_LIQUIDITY` | 100000 | Minimum pool liquidity in USD |
| `SCAN_INTERVAL` | 5000 | Milliseconds between scans |
| `AUTO_EXECUTE` | true | Automatically execute profitable trades |
| `DRY_RUN` | false | Simulate without executing trades |

## Supported DEXes

- Uniswap V3
- Uniswap V2
- SushiSwap
- Curve Finance

More DEXes can be added by updating the `DEXES` array in `bot.js`.

## Deploying to Cloud

### Railway (Recommended)

1. Push to GitHub
2. Connect repo to Railway
3. Set environment variables in Railway dashboard
4. Deploy

```bash
# Or use Railway CLI
railway link
railway up
```

### Render

1. Create new Web Service
2. Connect GitHub repo
3. Set build command: `npm install`
4. Set start command: `npm start`
5. Add environment variables
6. Deploy

### Heroku

```bash
heroku create your-app-name
heroku buildpacks:add heroku/nodejs
git push heroku main
heroku config:set BASE_RPC=https://mainnet.base.org
heroku config:set FLASH_ROUTER_BASE=0x...
```

## Monitoring

### View Running Logs

```bash
# Local
npm run logs

# Cloud (Railway)
railway logs

# Cloud (Render)
# Check dashboard > Service > Logs
```

### Check Bot Statistics

The bot logs statistics on shutdown:
- Total opportunities found
- Trades executed
- Average profit percentage
- Total profit across all trades

### Alerts

Bot logs include severity levels:
- 🤖 Initialization
- 🔍 Scanning
- 💰 Opportunities found
- ⚡ Executing trades
- ✅ Success
- ⚠️ Warnings
- ❌ Errors

## Troubleshooting

### Bot not finding opportunities

1. Check RPC endpoints are working
2. Verify smart contract addresses are correct
3. Increase `SCAN_INTERVAL` for more thorough scans
4. Lower `MIN_PROFIT_THRESHOLD` temporarily to test

### Trades failing

1. Check private key is valid
2. Verify wallet has sufficient balance for gas
3. Confirm smart contract addresses match
4. Check gas price settings aren't too low

### High gas costs

1. Reduce `SCAN_INTERVAL` to scan less frequently
2. Increase `MIN_PROFIT_THRESHOLD` to only execute larger arbitrages
3. Monitor gas prices and scan during low-traffic periods

### Logs getting too large

Logs rotate daily. Old logs can be archived:

```bash
tar -czf logs-backup-2026-09.tar.gz logs/
rm logs/*.log
```

## Performance Tips

1. **Scan Interval:** Start at 5s, adjust based on opportunities
2. **Liquidity Requirement:** $100k is safe, can adjust based on capital
3. **Profit Threshold:** 1% is realistic, lower = more trades but less profit per trade
4. **DEX Selection:** Consider focusing on fastest/most liquid DEXes

## Security Considerations

⚠️ **IMPORTANT:**

- Never commit private keys to Git
- Use `.env` file (add to `.gitignore`)
- Rotate keys regularly
- Monitor transactions for unusual activity
- Use rate limiting to prevent abuse
- Consider multi-sig wallet for large amounts

## Testing

```bash
npm test
```

Tests cover:
- Opportunity detection logic
- Profitability calculations
- Network connectivity
- Trade execution simulation

## Support

For issues or questions:
- Check logs in `logs/` directory
- Review DEPLOYMENT.md for general deployment help
- See SECURITY.md for security best practices

---

**Status:** Beta
**Last Updated:** September 3, 2026
